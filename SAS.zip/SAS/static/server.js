const express = require('express');
const path = require('path');
const fs = require('fs');
const csv = require('csv-parser');
const csvWriter = require('csv-writer').createObjectCsvWriter;
const bcrypt = require('bcrypt');
const session = require('express-session');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static('.'));
app.use(session({
    secret: 'smart-attendance-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
}));

// File paths
const USERS_FILE = 'users.csv';
const ATTENDANCE_FILE = 'attendance.csv';

// Helper functions
function hashPassword(password) {
    return require('crypto').createHash('sha256').update(password).digest('hex');
}

function loadUsers() {
    const users = {};
    if (fs.existsSync(USERS_FILE)) {
        const data = fs.readFileSync(USERS_FILE, 'utf8');
        const lines = data.trim().split('\n');
        lines.forEach(line => {
            const [username, password] = line.split(',');
            if (username && password) {
                users[username] = password;
            }
        });
    }
    return users;
}

function ensureAttendanceFile() {
    if (!fs.existsSync(ATTENDANCE_FILE)) {
        const header = 'Name,Date,Time,Status\n';
        fs.writeFileSync(ATTENDANCE_FILE, header);
    }
}

function markAttendance(name) {
    ensureAttendanceFile();
    const now = new Date();
    const date = now.toISOString().split('T')[0];
    const time = now.toTimeString().split(' ')[0];
    const record = `${name},${date},${time},Present\n`;
    fs.appendFileSync(ATTENDANCE_FILE, record);
    return { name, date, time, status: 'Present' };
}

function getTodayAttendance() {
    const today = new Date().toISOString().split('T')[0];
    const records = [];
    
    if (fs.existsSync(ATTENDANCE_FILE)) {
        const data = fs.readFileSync(ATTENDANCE_FILE, 'utf8');
        const lines = data.trim().split('\n');
        
        // Skip header
        for (let i = 1; i < lines.length; i++) {
            const [name, date, time, status] = lines[i].split(',');
            if (date === today) {
                records.push({ name, date, time, status });
            }
        }
    }
    
    return records;
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/dashboard', (req, res) => {
    if (!req.session.isLoggedIn) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const users = loadUsers();
    
    if (users[username] && users[username] === hashPassword(password)) {
        req.session.isLoggedIn = true;
        req.session.username = username;
        res.json({ success: true, message: 'Login successful' });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true, message: 'Logged out successfully' });
});

app.get('/api/attendance', (req, res) => {
    if (!req.session.isLoggedIn) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    
    const records = getTodayAttendance();
    res.json({ success: true, records });
});

app.post('/api/mark-attendance', (req, res) => {
    if (!req.session.isLoggedIn) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    
    const { name } = req.body;
    if (!name) {
        return res.status(400).json({ success: false, message: 'Name is required' });
    }
    
    const record = markAttendance(name);
    res.json({ success: true, record, message: `Attendance marked for ${name}` });
});

app.get('/api/stats', (req, res) => {
    if (!req.session.isLoggedIn) {
        return res.status(401).json({ success: false, message: 'Not authenticated' });
    }
    
    const records = getTodayAttendance();
    const uniqueNames = new Set(records.map(r => r.name));
    const totalPresent = uniqueNames.size;
    
    let lastAttendance = '--:--';
    if (records.length > 0) {
        const sortedRecords = records.sort((a, b) => b.time.localeCompare(a.time));
        lastAttendance = sortedRecords[0].time;
    }
    
    const currentDate = new Date().toLocaleDateString();
    
    res.json({
        success: true,
        stats: {
            totalPresent,
            lastAttendance,
            currentDate
        }
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Smart Attendance System running on http://localhost:${PORT}`);
    console.log('Default admin credentials:');
    console.log('Username: admin');
    console.log('Password: admin123');
});
