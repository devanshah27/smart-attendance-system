// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    let videoStream = null;
    let isCameraActive = false;
    let recognitionInterval = null;
    
    // DOM elements
    const startCameraBtn = document.getElementById('startCameraBtn');
    const stopCameraBtn = document.getElementById('stopCameraBtn');
    const videoElement = document.getElementById('videoElement');
    const canvasElement = document.getElementById('canvasElement');
    const cameraPlaceholder = document.getElementById('cameraPlaceholder');
    const recognitionStatus = document.getElementById('recognitionStatus');
    const refreshAttendanceBtn = document.getElementById('refreshAttendanceBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const attendanceRecords = document.getElementById('attendanceRecords');
    const totalPresent = document.getElementById('totalPresent');
    const lastAttendance = document.getElementById('lastAttendance');
    const currentDate = document.getElementById('currentDate');
    
    // Initialize dashboard
    initializeDashboard();
    
    // Event listeners
    startCameraBtn.addEventListener('click', startCamera);
    stopCameraBtn.addEventListener('click', stopCamera);
    refreshAttendanceBtn.addEventListener('click', loadAttendanceRecords);
    logoutBtn.addEventListener('click', logout);
    
    async function initializeDashboard() {
        await loadAttendanceRecords();
        await loadStats();
        updateCurrentDate();
    }
    
    async function startCamera() {
        try {
            // Start backend camera
            const response = await fetch('/api/start-camera', {
                method: 'POST'
            });
            
            if (!response.ok) {
                throw new Error('Failed to start backend camera');
            }
            
            // Start browser camera for display
            videoStream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                } 
            });
            
            videoElement.srcObject = videoStream;
            videoElement.style.display = 'block';
            cameraPlaceholder.style.display = 'none';
            
            startCameraBtn.disabled = true;
            stopCameraBtn.disabled = false;
            isCameraActive = true;
            
            updateStatus('Camera started. Looking for faces...', 'recognizing');
            
            // Start face recognition processing
            startFaceRecognition();
            
        } catch (error) {
            console.error('Error accessing camera:', error);
            showNotification('Camera access denied. Please allow camera permissions.', 'error');
        }
    }
    
    function stopCamera() {
        // Stop browser camera
        if (videoStream) {
            videoStream.getTracks().forEach(track => track.stop());
            videoStream = null;
        }
        
        // Stop backend camera
        fetch('/api/stop-camera', {
            method: 'POST'
        }).catch(error => {
            console.error('Error stopping backend camera:', error);
        });
        
        // Stop recognition interval
        if (recognitionInterval) {
            clearInterval(recognitionInterval);
            recognitionInterval = null;
        }
        
        videoElement.style.display = 'none';
        cameraPlaceholder.style.display = 'block';
        
        startCameraBtn.disabled = false;
        stopCameraBtn.disabled = true;
        isCameraActive = false;
        
        updateStatus('Camera stopped', 'default');
    }
    
    function startFaceRecognition() {
        if (!isCameraActive) return;
        
        // Capture frames every 2 seconds for face recognition
        recognitionInterval = setInterval(async () => {
            if (!isCameraActive) return;
            
            try {
                // Capture frame from video element
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = videoElement.videoWidth;
                canvas.height = videoElement.videoHeight;
                ctx.drawImage(videoElement, 0, 0);
                
                // Convert to base64
                const imageData = canvas.toDataURL('image/jpeg', 0.8);
                
                // Send to backend for face recognition
                const response = await fetch('/api/recognize-face', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ image: imageData })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    if (data.recognized) {
                        if (data.blink_passed) {
                            updateStatus(`Attendance marked for ${data.name}`, 'success');
                            showNotification(data.message, 'success');
                            await loadAttendanceRecords();
                            await loadStats();
                        } else {
                            updateStatus(`Recognized ${data.name} - Blink required`, 'recognizing');
                        }
                    } else {
                        updateStatus('No known face detected', 'default');
                    }
                }
                
            } catch (error) {
                console.error('Face recognition error:', error);
                updateStatus('Recognition error', 'default');
            }
        }, 2000); // Process every 2 seconds
    }
    
    async function loadAttendanceRecords() {
        try {
            const response = await fetch('/api/attendance');
            const data = await response.json();
            
            if (data.success) {
                displayAttendanceRecords(data.records);
            } else {
                console.error('Failed to load attendance records');
            }
        } catch (error) {
            console.error('Error loading attendance records:', error);
        }
    }
    
    function displayAttendanceRecords(records) {
        if (records.length === 0) {
            attendanceRecords.innerHTML = `
                <div class="no-records">
                    <i class="fas fa-clipboard"></i>
                    <p>No attendance records for today</p>
                </div>
            `;
            return;
        }
        
        // Group records by name and show latest time for each person
        const groupedRecords = {};
        records.forEach(record => {
            if (!groupedRecords[record.Name] || record.Time > groupedRecords[record.Name].Time) {
                groupedRecords[record.Name] = record;
            }
        });
        
        const sortedRecords = Object.values(groupedRecords).sort((a, b) => b.Time.localeCompare(a.Time));
        
        attendanceRecords.innerHTML = sortedRecords.map(record => `
            <div class="attendance-record fade-in">
                <div class="record-info">
                    <div class="record-name">${record.Name}</div>
                    <div class="record-time">${record.Time}</div>
                </div>
                <div class="record-status">${record.Status}</div>
            </div>
        `).join('');
    }
    
    async function loadStats() {
        try {
            const response = await fetch('/api/stats');
            const data = await response.json();
            
            if (data.success) {
                const stats = data.stats;
                totalPresent.textContent = stats.total_present;
                lastAttendance.textContent = stats.last_attendance;
            }
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }
    
    function updateCurrentDate() {
        const now = new Date();
        currentDate.textContent = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
    
    function updateStatus(message, type = 'default') {
        recognitionStatus.innerHTML = `
            <i class="fas fa-eye"></i>
            <span>${message}</span>
        `;
        
        recognitionStatus.className = `status-indicator ${type}`;
    }
    
    function showNotification(message, type = 'info') {
        const toast = document.getElementById('notificationToast');
        const toastIcon = toast.querySelector('.toast-icon');
        const toastMessage = toast.querySelector('.toast-message');
        
        // Set icon based on type
        let iconClass = 'fas fa-info-circle';
        if (type === 'success') iconClass = 'fas fa-check-circle';
        if (type === 'error') iconClass = 'fas fa-exclamation-circle';
        
        toastIcon.className = `toast-icon ${iconClass}`;
        toastMessage.textContent = message;
        
        toast.className = `notification-toast ${type} show`;
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
    
    async function logout() {
        try {
            // Stop camera before logout
            if (isCameraActive) {
                stopCamera();
            }
            
            const response = await fetch('/api/logout', {
                method: 'POST'
            });
            
            if (response.ok) {
                window.location.href = '/';
            }
        } catch (error) {
            console.error('Logout error:', error);
            // Force redirect even if API call fails
            window.location.href = '/';
        }
    }
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (videoStream) {
            videoStream.getTracks().forEach(track => track.stop());
        }
        if (recognitionInterval) {
            clearInterval(recognitionInterval);
        }
    });
});
