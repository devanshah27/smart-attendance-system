"""
Smart Attendance System (Web Interface)
- Blink-based liveness check
- Attendance marked after 3 blinks
- Optimized for speed (resized frames)
- Stored in CSV
- Only recognizes known faces (distance threshold applied)
- Web interface with Flask
"""

import os
import csv
import cv2
import hashlib
import face_recognition
import numpy as np
from datetime import datetime
import getpass
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
import base64
import io
from PIL import Image
import threading
import time

# ----------------------------
# CONFIG & PATHS
# ----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # Script folder
KNOWN_FOLDER = os.path.join(BASE_DIR, "face_test/known")
USERS_FILE = os.path.join(BASE_DIR, "users.csv")
ATTENDANCE_FILE = os.path.join(BASE_DIR, "attendance.csv")

BLINK_THRESHOLD = 0.25        # EAR below this is considered a blink
REQUIRED_BLINKS = 3           # Blinks required to mark attendance
FRAME_SCALE = 0.5             # Resize frame to 50% for faster processing
FACE_DISTANCE_THRESHOLD = 0.5 # Max distance for recognition

# ----------------------------
# SECURITY FUNCTIONS
# ----------------------------
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def create_default_user_if_missing():
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["admin", hash_password("admin123")])
        print(f"[SETUP] Created default user -> {USERS_FILE}")

def load_users():
    users = {}
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, "r", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) >= 2:
                    users[row[0]] = row[1]
    print(f"[DEBUG] Loaded users: {list(users.keys())}")
    return users

def login_prompt():
    users = load_users()
    while True:
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ")
        if username in users and users[username] == hash_password(password):
            print(f"[SECURITY] Login successful. Welcome {username}!")
            return True
        else:
            print("[SECURITY] Login failed! Try again.")

# ----------------------------
# ATTENDANCE CSV
# ----------------------------
def ensure_attendance_file():
    if not os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE,"w",newline="") as f:
            writer=csv.writer(f)
            writer.writerow(["Name","Date","Time","Status"])
        print(f"[SETUP] Created attendance file -> {ATTENDANCE_FILE}")

def mark_attendance(name):
    now = datetime.now()
    with open(ATTENDANCE_FILE,"a",newline="") as f:
        writer = csv.writer(f)
        writer.writerow([name, now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S"), "Present"])
    print(f"[ATTENDANCE] Marked {name} present at {now.strftime('%H:%M:%S')}")
    return {
        "name": name,
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "status": "Present"
    }

# ----------------------------
# FACE UTILITIES
# ----------------------------
def load_known_faces(folder=KNOWN_FOLDER):
    encs,names=[],[]
    if not os.path.exists(folder):
        raise FileNotFoundError(f"Known folder not found: {folder}")
    for fname in os.listdir(folder):
        if fname.lower().endswith((".jpg",".jpeg",".png")):
            path=os.path.join(folder,fname)
            img=face_recognition.load_image_file(path)
            enc=face_recognition.face_encodings(img)
            if enc:
                encs.append(enc[0])
                names.append(os.path.splitext(fname)[0].capitalize())
            else:
                print(f"[WARN] No face encoding in {fname}, skipping.")
    return encs,names

def eye_aspect_ratio(eye_points):
    A = np.linalg.norm(np.array(eye_points[1]) - np.array(eye_points[5]))
    B = np.linalg.norm(np.array(eye_points[2]) - np.array(eye_points[4]))
    C = np.linalg.norm(np.array(eye_points[0]) - np.array(eye_points[3]))
    return (A + B) / (2.0 * C) if C != 0 else 1.0

# ----------------------------
# LIVENESS (BLINK) CHECK
# ----------------------------
_blink_history = {}  # Track blinks per student

def check_blink_liveness(face_name, face_landmarks):
    blink_detected = False
    if face_landmarks:
        lm = face_landmarks[0]
        left_eye = lm.get("left_eye", [])
        right_eye = lm.get("right_eye", [])
        if left_eye and right_eye and len(left_eye) >= 6 and len(right_eye) >= 6:
            ear = (eye_aspect_ratio(left_eye) + eye_aspect_ratio(right_eye)) / 2.0
            if ear < BLINK_THRESHOLD:
                blink_detected = True

    if face_name not in _blink_history:
        _blink_history[face_name] = 0

    if blink_detected:
        _blink_history[face_name] += 1

    return _blink_history[face_name] >= REQUIRED_BLINKS

# ----------------------------
# FLASK WEB SERVER
# ----------------------------
app = Flask(__name__)
app.secret_key = 'smart-attendance-secret-key-2024'
CORS(app)

# Global variables for face recognition
known_encodings = []
known_names = []
video_capture = None
is_camera_active = False
marked_names = set()

def process_face_recognition(image_data):
    """Process face recognition on uploaded image"""
    try:
        # Decode base64 image
        image_bytes = base64.b64decode(image_data.split(',')[1])
        image = Image.open(io.BytesIO(image_bytes))
        frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        
        # Resize frame for faster processing
        small_frame = cv2.resize(frame, (0, 0), fx=FRAME_SCALE, fy=FRAME_SCALE)
        rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
        
        face_locations = face_recognition.face_locations(rgb_small)
        face_encodings = face_recognition.face_encodings(rgb_small, face_locations)
        
        results = []
        
        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            name = "Unknown"
            confidence = 0
            
            if known_encodings:
                face_distances = face_recognition.face_distance(known_encodings, face_encoding)
                best_idx = np.argmin(face_distances)
                if face_distances[best_idx] < FACE_DISTANCE_THRESHOLD:
                    name = known_names[best_idx]
                    confidence = 1 - face_distances[best_idx]
                    
                    # Check for blink liveness
                    landmarks = face_recognition.face_landmarks(rgb_small[top:bottom, left:right])
                    blink_passed = check_blink_liveness(name, landmarks)
                    
                    # For testing, you can uncomment the next line to skip blink check
                    # blink_passed = True
                    
                    results.append({
                        "name": name,
                        "confidence": confidence,
                        "blink_passed": blink_passed,
                        "location": {
                            "top": int(top / FRAME_SCALE),
                            "right": int(right / FRAME_SCALE),
                            "bottom": int(bottom / FRAME_SCALE),
                            "left": int(left / FRAME_SCALE)
                        }
                    })
        
        return results
        
    except Exception as e:
        print(f"[ERROR] Face recognition failed: {e}")
        return []

def get_today_attendance():
    today = datetime.now().strftime("%Y-%m-%d")
    records = []
    
    if os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE, "r", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["Date"] == today:
                    records.append(row)
    
    return records

def start_camera():
    """Start laptop camera for face recognition"""
    global video_capture, is_camera_active
    try:
        video_capture = cv2.VideoCapture(0)  # Use laptop camera (index 0)
        if not video_capture.isOpened():
            print("[ERROR] Cannot open laptop camera.")
            return False
        
        is_camera_active = True
        print("[INFO] Laptop camera opened successfully.")
        return True
    except Exception as e:
        print(f"[ERROR] Failed to start camera: {e}")
        return False

def stop_camera():
    """Stop laptop camera"""
    global video_capture, is_camera_active
    if video_capture:
        video_capture.release()
        video_capture = None
    is_camera_active = False
    print("[INFO] Camera stopped.")

# ----------------------------
# FLASK ROUTES
# ----------------------------
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('is_logged_in'):
        return redirect(url_for('index'))
    return render_template('dashboard.html')

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    users = load_users()
    
    if username in users and users[username] == hash_password(password):
        session['is_logged_in'] = True
        session['username'] = username
        return jsonify({"success": True, "message": "Login successful"})
    else:
        return jsonify({"success": False, "message": "Invalid credentials"}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    stop_camera()  # Stop camera when logging out
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"})

@app.route('/api/attendance', methods=['GET'])
def get_attendance():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    records = get_today_attendance()
    return jsonify({"success": True, "records": records})

@app.route('/api/mark-attendance', methods=['POST'])
def mark_attendance_api():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    data = request.get_json()
    name = data.get('name')
    
    if not name:
        return jsonify({"success": False, "message": "Name is required"}), 400
    
    record = mark_attendance(name)
    return jsonify({"success": True, "record": record, "message": f"Attendance marked for {name}"})

@app.route('/api/recognize-face', methods=['POST'])
def recognize_face():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    data = request.get_json()
    image_data = data.get('image')
    
    if not image_data:
        return jsonify({"success": False, "message": "Image data is required"}), 400
    
    results = process_face_recognition(image_data)
    
    if results:
        # Get the first recognized face
        face_result = results[0]
        if face_result['blink_passed']:
            # Mark attendance
            record = mark_attendance(face_result['name'])
            return jsonify({
                "success": True,
                "recognized": True,
                "name": face_result['name'],
                "confidence": face_result['confidence'],
                "record": record,
                "message": f"Attendance marked for {face_result['name']}"
            })
        else:
            return jsonify({
                "success": True,
                "recognized": True,
                "name": face_result['name'],
                "confidence": face_result['confidence'],
                "blink_passed": False,
                "message": f"Recognized {face_result['name']} but blink verification required"
            })
    else:
        return jsonify({
            "success": True,
            "recognized": False,
            "message": "No known face detected"
        })

@app.route('/api/stats', methods=['GET'])
def get_stats():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    records = get_today_attendance()
    unique_names = set(record['Name'] for record in records)
    total_present = len(unique_names)
    
    last_attendance = "--:--"
    if records:
        sorted_records = sorted(records, key=lambda x: x['Time'], reverse=True)
        last_attendance = sorted_records[0]['Time']
    
    current_date = datetime.now().strftime("%A, %B %d, %Y")
    
    return jsonify({
        "success": True,
        "stats": {
            "total_present": total_present,
            "last_attendance": last_attendance,
            "current_date": current_date
        }
    })

@app.route('/api/start-camera', methods=['POST'])
def start_camera_api():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    if start_camera():
        return jsonify({"success": True, "message": "Camera started successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to start camera"}), 500

@app.route('/api/stop-camera', methods=['POST'])
def stop_camera_api():
    if not session.get('is_logged_in'):
        return jsonify({"success": False, "message": "Not authenticated"}), 401
    
    stop_camera()
    return jsonify({"success": True, "message": "Camera stopped successfully"})

# ----------------------------
# MAIN LOOP (Original functionality preserved)
# ----------------------------
def main():
    """Original console-based main function (preserved for compatibility)"""
    print("Users CSV path:", USERS_FILE)
    print("Attendance CSV path:", ATTENDANCE_FILE)

    create_default_user_if_missing()
    login_prompt()

    known_encodings, known_names = load_known_faces()
    if not known_encodings:
        print("[ERROR] No known faces loaded. Exiting.")
        return
    print(f"[INFO] Loaded faces: {known_names}")

    ensure_attendance_file()
    marked_names = set()

    video_capture = cv2.VideoCapture(0)  # Use laptop camera
    if not video_capture.isOpened():
        print("[ERROR] Cannot open laptop camera.")
        return
    print("[INFO] Laptop camera opened. Press 'q' to quit.")

    try:
        while True:
            ret, frame = video_capture.read()
            if not ret: break

            # Resize frame for faster processing
            small_frame = cv2.resize(frame, (0,0), fx=FRAME_SCALE, fy=FRAME_SCALE)
            rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            face_locations = face_recognition.face_locations(rgb_small)
            face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                name = "Unknown"
                color = (0,0,255)

                if known_encodings:
                    face_distances = face_recognition.face_distance(known_encodings, face_encoding)
                    best_idx = np.argmin(face_distances)
                    if face_distances[best_idx] < FACE_DISTANCE_THRESHOLD:
                        name = known_names[best_idx]
                        landmarks = face_recognition.face_landmarks(rgb_small[top:bottom, left:right])
                        blink_passed = check_blink_liveness(name, landmarks)

                        # ----------------------------
                        # For testing without blinking, uncomment next line:
                        # blink_passed = True
                        # ----------------------------

                        if blink_passed and name not in marked_names:
                            mark_attendance(name)
                            marked_names.add(name)
                            color = (0,255,0)
                            print("inside geolocation")

                # Draw rectangle
                top_s, right_s, bottom_s, left_s = [int(x / FRAME_SCALE) for x in (top, right, bottom, left)]
                cv2.rectangle(frame, (left_s, top_s), (right_s, bottom_s), color, 2)
                cv2.putText(frame, name, (left_s, top_s-10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

            cv2.imshow("Smart Attendance System", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'): break

    finally:
        video_capture.release()
        cv2.destroyAllWindows()
        print("[INFO] Exiting. Attendance saved to", ATTENDANCE_FILE)

def run_web_server():
    """Initialize and run the Flask web server"""
    print("=" * 60)
    print("SMART ATTENDANCE SYSTEM - WEB INTERFACE")
    print("=" * 60)
    print("Users CSV path:", USERS_FILE)
    print("Attendance CSV path:", ATTENDANCE_FILE)
    print("Face database path:", KNOWN_FOLDER)
    
    # Initialize system
    create_default_user_if_missing()
    ensure_attendance_file()
    
    # Load known faces
    global known_encodings, known_names
    known_encodings, known_names = load_known_faces()
    
    if not known_encodings:
        print("[ERROR] No known faces loaded from face_test/known folder.")
        print("[INFO] Please add face images to face_test/known/ folder.")
        return
    
    print(f"[INFO] Loaded faces: {known_names}")
    print(f"[INFO] Using laptop camera (index 0)")
    print()
    print("Default admin credentials:")
    print("Username: admin")
    print("Password: admin123")
    print()
    print("Access the system at: http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    
    # Start Flask server
    app.run(debug=True, host='0.0.0.0', port=5000)

if __name__ == "__main__":
    import sys
    
    # Check if running in web mode or console mode
    if len(sys.argv) > 1 and sys.argv[1] == "--web":
        run_web_server()
    else:
        print("Starting console mode...")
        print("For web interface, run: python attendance_system.py --web")
        print()
        main()
